"""brascch URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from neonatal.views import home
from neonatal.views import listagem_criterio
from neonatal.views import novo_criterio
from neonatal.views import update_criterio
from neonatal.views import delete_criterio
from neonatal.views import listagem_categoria
from neonatal.views import nova_categoria
from neonatal.views import update_categoria
from neonatal.views import delete_categoria
from neonatal.views import listagem_visualizacao
from neonatal.views import mostra_grafico


urlpatterns = [
    url('admin/', admin.site.urls),
    url('home/', home, name='url_home'),
    path('listagem_categoria/', listagem_categoria, name='url_listagem_categoria'),
    path('nova_categoria/', nova_categoria, name='url_nova_categoria'),
    path('update_categoria/<int:pk>/', update_categoria, name='url_update_categoria'),
    path('delete_categoria/<int:pk>/', delete_categoria, name='url_delete_categoria'),
    url('listagem_criterio/', listagem_criterio, name='url_listagem_criterio'),
    url('novo_criterio/', novo_criterio, name='url_novo_criterio'),
    path('update_criterio/<int:pk>/', update_criterio, name='url_update_criterio'),
    path('delete_criterio/<int:pk>/', delete_criterio, name='url_delete_criterio'),
    url('listagem_visualizacao/', listagem_visualizacao, name='url_listagem_visualizacao'),
    path('mostra_grafico/<int:pk>/', mostra_grafico, name='url_mostra_grafico'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)