from django.apps import AppConfig


class NeonatalConfig(AppConfig):
    name = 'neonatal'
