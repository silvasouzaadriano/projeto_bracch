from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage
from neonatal.models import Categorias, Criterios
from neonatal.forms import CategoriaForm, CriterioForm

import datetime

# Create your views here.
def home(request):
    data = {}
    data['now']= datetime.datetime.now()
    return render(request,'neonatal/home.html', data)

def listagem_categoria(request):
    data = {}
    data['categorias'] = Categorias.objects.all()
    return render(request,'neonatal/listagem_categoria.html', data)

def nova_categoria(request):
    data = {}
    form = CategoriaForm(request.POST or None)

    if form.is_valid():
        form.save()
        return redirect('url_listagem_categoria')
    data['form'] = form
    return render(request,'neonatal/form_categoria.html', data)

def update_categoria(request, pk):
    data = {}
    categoria = Categorias.objects.get(pk=pk)
    form = CategoriaForm(request.POST or None, instance = categoria)

    if form.is_valid():
        form.save()
        return redirect('url_listagem_categoria')
    data['form'] = form
    data['categoria'] = categoria
    return render(request,'neonatal/form_categoria.html', data)

def delete_categoria(request,pk):
    categoria = Categorias.objects.get(pk=pk)
    categoria.delete()
    return redirect('url_listagem_categoria')

def listagem_criterio(request):
    data = {}
    data['criterios'] = Criterios.objects.all()
    return render(request, 'neonatal/listagem_criterio.html', data)

def novo_criterio(request):
    data = {}
    if request.method == 'POST':
        form = CriterioForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('url_listagem_criterio')
    else:
        form = CriterioForm()
    data['form'] = form
    return render(request, 'neonatal/form_criterio.html', data)

def update_criterio(request, pk):
    data = {}
    criterio = Criterios.objects.get(pk=pk)
    form = CriterioForm(request.POST or None, request.FILES or None, instance=criterio)
    if form.is_valid():
        form.save()
        return redirect('url_listagem_criterio')
    data['form'] = form
    data['criterio'] = criterio
    return render(request, 'neonatal/form_criterio.html', data)

def delete_criterio(request,pk):
    criterio = Criterios.objects.get(pk=pk)
    criterio.delete()
    return redirect('url_listagem_criterio')

def listagem_visualizacao(request):
    data = {}
    data['criterios'] = Criterios.objects.all()
    return render(request, 'neonatal/listagem_visualizacao.html', data)

def mostra_grafico(request, pk):
    data = {}
    criterio = Criterios.objects.get(pk=pk)
    data['criterio'] = criterio
    return render(request, 'neonatal/mostra_grafico.html', data)




