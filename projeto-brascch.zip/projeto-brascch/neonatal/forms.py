from django import forms

from neonatal.models import Categorias, Criterios

class CategoriaForm(forms.ModelForm):
    class Meta:
        model = Categorias
        fields = ['nome']

class CriterioForm(forms.ModelForm):
    class Meta:
        model = Criterios
        fields = ['titulo','descricao','categoria1', 'categoria2', 'categoria3', 'thumbnail','arquivo_js','arquivo_json']







