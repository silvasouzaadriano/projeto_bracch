from django.contrib import admin
from .models import Categorias, Criterios

# Register your models here.
admin.site.register(Categorias)
admin.site.register(Criterios)
