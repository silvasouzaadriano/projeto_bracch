#from __future__ import unicode_literals
from django.db import models

# Create your models here.
class Categorias(models.Model):
    nome = models.CharField(max_length=200)
    dt_criacao = models.DateTimeField(auto_now_add=True, verbose_name='Data de Criação')

    def __str__(self):
        return self.nome

class Criterios(models.Model):
    titulo = models.CharField(max_length=200, verbose_name='Título')
    descricao = models.TextField(null=True, blank=True,max_length=500,verbose_name='Descrição')
    categoria1 = models.ForeignKey(Categorias, related_name='categoria1_set', null=True, blank=True, on_delete=models.CASCADE, verbose_name='Categoria 1')
    categoria2 = models.ForeignKey(Categorias, related_name='categoria2_set', null=True, blank=True, on_delete=models.CASCADE, verbose_name='Categoria 2')
    categoria3 = models.ForeignKey(Categorias, related_name='categoria3_set', null=True, blank=True, on_delete=models.CASCADE, verbose_name='Categoria 3')
    thumbnail = models.ImageField(upload_to='documents/thumbnails/', default='documents/thumbnails/imagedefault.jpg')
    arquivo_js = models.FileField(upload_to='documents/js/')
    arquivo_json = models.FileField(upload_to='documents/json/')
    data_upload = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = 'Criterios'

    def __str__(self):
        return self.descricao

    def delete(self,*args, **kwargs):
        self.thumbnail.delete()
        self.arquivo_js.delete()
        self.arquivo_json.delete()
        super().delete(*args, **kwargs)
